<?php
session_start();
include "koneksi.php";

$id = $_GET['id'];
$data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT foto FROM kue WHERE id=$id"));

unlink("uploads/" . $data['foto']);

mysqli_query($conn, "DELETE FROM kue WHERE id=$id");

header("Location: dashboard.php");
exit;
?>
