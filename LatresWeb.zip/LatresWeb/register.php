<?php
session_start();
include "koneksi.php";

if(isset($_POST['register'])){
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $sql = "INSERT INTO users(username, password) VALUES('$username', '$password')";
    if(mysqli_query($conn, $sql)){
        header("Location: login.php");
        exit;
    } else {
        $error = "Username sudah digunakan!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"/>

    <style>
        body {
            background: #f4f6f9;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .card {
            width: 380px;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0px 3px 15px rgba(0,0,0,0.08);
        }

        .btn-register {
            background-color: #198754;
            color: white;
        }

        .btn-register:hover {
            background-color: #157347;
        }

        .title {
            font-weight: 600;
            margin-bottom: 15px;
        }
    </style>
</head>

<body>

<div class="card">
    <h4 class="text-center title">Register</h4>

    <?php if(isset($error)): ?>
    <div class="alert alert-danger p-2 text-center"><?= $error ?></div>
    <?php endif; ?>

    <form method="POST">
        <label>Username</label>
        <input type="text" name="username" class="form-control mb-3" required>

        <label>Password</label>
        <input type="password" name="password" class="form-control mb-3" required>

        <button class="btn btn-register w-100 mb-2" name="register">Register</button>

        <div class="text-center">
            Sudah punya akun? <a href="login.php">Login</a>
        </div>
    </form>
</div>

</body>
</html>
