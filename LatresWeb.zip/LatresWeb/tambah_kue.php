<?php
session_start();
if(!isset($_SESSION['username'])){
    header("Location: login.php");
    exit;
}

include "koneksi.php";

if(isset($_POST['submit'])){
    $nama  = $_POST['nama'];
    $harga = $_POST['harga'];
    $stok  = $_POST['stok'];

    $foto  = $_FILES['foto']['name'];
    $tmp   = $_FILES['foto']['tmp_name'];
    $unik  = time() . "_" . $foto;

    move_uploaded_file($tmp, "uploads/" . $unik);

    mysqli_query($conn, "INSERT INTO kue(nama, harga, stok, foto) 
                         VALUES('$nama', '$harga', '$stok', '$unik')");

    header("Location: dashboard.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Tambah Kue</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">

<style>
    body {
        background: #f4f6f9;
        height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
    }
    .card {
        width: 420px;
        padding: 25px;
        border-radius: 12px;
        box-shadow: 0px 3px 15px rgba(0,0,0,0.08);
    }
    .title {
        font-weight: 600;
    }
</style>

</head>
<body>

<div class="card">

    <h4 class="text-center title mb-3">Tambah Kue</h4>

    <form method="POST" enctype="multipart/form-data">

        <label>Foto</label>
        <input type="file" name="foto" class="form-control mb-3" required>

        <label>Nama Kue</label>
        <input type="text" name="nama" class="form-control mb-3" required>

        <label>Harga</label>
        <input type="number" name="harga" class="form-control mb-3" required>

        <label>Stok</label>
        <input type="number" name="stok" class="form-control mb-3" required>

        <div class="d-flex gap-2">
            <a href="dashboard.php" class="btn btn-secondary">Kembali</a>
            <button class="btn btn-primary" name="submit">Simpan</button>
        </div>

    </form>

</div>

</body>
</html>
