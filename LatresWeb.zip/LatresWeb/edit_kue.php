<?php
session_start();
if(!isset($_SESSION['username'])){
    header("Location: login.php");
    exit;
}

include "koneksi.php";
$id = $_GET['id'];
$data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM kue WHERE id=$id"));

if(isset($_POST['update'])){
    $nama  = $_POST['nama'];
    $harga = $_POST['harga'];
    $stok  = $_POST['stok'];

    if($_FILES['foto']['name'] != ""){
        unlink("uploads/" . $data['foto']);

        $foto = time() . "_" . $_FILES['foto']['name'];
        move_uploaded_file($_FILES['foto']['tmp_name'], "uploads/" . $foto);
    } else {
        $foto = $data['foto'];
    }

    mysqli_query($conn, "UPDATE kue SET 
        nama='$nama',
        harga='$harga',
        stok='$stok',
        foto='$foto'
        WHERE id=$id");

    header("Location: dashboard.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Edit Kue</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">

<style>
    body {
        background: #f4f6f9;
        height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
    }
    .card {
        width: 450px;
        padding: 25px;
        border-radius: 12px;
        box-shadow: 0px 3px 15px rgba(0,0,0,0.08);
    }
    .title {
        font-weight: 600;
    }
    .preview-img {
        width: 100%;
        height: 210px;
        object-fit: cover;
        border-radius: 10px;
        margin-bottom: 15px;
        border: 1px solid #ddd;
    }
</style>

</head>
<body>

<div class="card">

    <h4 class="text-center title mb-3">Edit Kue</h4>

    <form method="POST" enctype="multipart/form-data">

        <img src="uploads/<?= $data['foto'] ?>" class="preview-img">
        
        <label>Ganti Foto (opsional)</label>
        <input type="file" name="foto" class="form-control mb-3">

        <label>Nama Kue</label>
        <input type="text" name="nama" class="form-control mb-3" value="<?= $data['nama'] ?>" required>

        <label>Harga</label>
        <input type="number" name="harga" class="form-control mb-3" value="<?= $data['harga'] ?>" required>

        <label>Stok</label>
        <input type="number" name="stok" class="form-control mb-3" value="<?= $data['stok'] ?>" required>


        <div class="d-flex gap-2 mt-2">
            <a href="dashboard.php" class="btn btn-secondary">Kembali</a>
            <button class="btn btn-warning" name="update">Update</button>
        </div>

    </form>

</div>

</body>
</html>
