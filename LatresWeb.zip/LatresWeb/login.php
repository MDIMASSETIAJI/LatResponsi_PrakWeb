<?php
session_start();
include "koneksi.php";

if(isset($_POST['login'])){
    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql  = "SELECT * FROM users WHERE username='$username'";
    $data = mysqli_query($conn, $sql);

    if(!$data){
        die("Query error: " . mysqli_error($conn));
    }

    $row = mysqli_fetch_assoc($data);

    if($row && password_verify($password, $row['password'])){
        $_SESSION['username'] = $row['username'];
        header("Location: dashboard.php");
        exit;
    } else {
        $error = "Username atau Password salah!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"/>

    <style>
        body {
            background: #f4f6f9;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .card {
            width: 380px;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0px 3px 15px rgba(0,0,0,0.08);
        }

        .btn-login {
            background-color: #0d6efd;
            color: white;
        }

        .btn-login:hover {
            background-color: #0b5ed7;
        }

        .title {
            font-weight: 600;
            margin-bottom: 15px;
        }
    </style>
</head>

<body>

<div class="card">
    <h4 class="text-center title">Login</h4>

    <?php if(isset($error)): ?>
    <div class="alert alert-danger p-2 text-center"><?= $error ?></div>
    <?php endif; ?>

    <form method="POST">

        <label>Username</label>
        <input type="text" name="username" class="form-control mb-3" required>

        <label>Password</label>
        <input type="password" name="password" class="form-control mb-3" required>

        <button class="btn btn-login w-100 mb-2" name="login">Login</button>

        <div class="text-center">
            Belum punya akun? <a href="register.php">Register</a>
        </div>
    </form>
</div>

</body>
</html>
