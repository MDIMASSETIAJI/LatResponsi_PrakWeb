<?php
session_start();
if(!isset($_SESSION['username'])){
    header("Location: login.php");
    exit;
}

include "koneksi.php";
$kue = mysqli_query($conn, "SELECT * FROM kue ORDER BY id DESC");
?>

<!DOCTYPE html>
<html>
<head>
<title>Dashboard</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
</head>
<body class="container py-4">

<div class="d-flex justify-content-between align-items-center mb-4">
    <h3 class="m-0">Katalog Kue</h3>
    <a href="logout.php" class="btn btn-danger">Logout</a>
</div>


<div class="row">
<?php while($row = mysqli_fetch_assoc($kue)) : ?>
    <div class="col-md-4 mb-4">
        <div class="card">
            <img src="uploads/<?= $row['foto'] ?>" class="card-img-top" height="200" style="object-fit:cover;">
            <div class="card-body">
                <h5><?= $row['nama'] ?></h5>
                <p>Harga: Rp<?= number_format($row['harga']) ?></p>
                <p>Stok: <?= $row['stok'] ?></p>

                <a href="edit_kue.php?id=<?= $row['id'] ?>" class="btn btn-warning btn-sm">Edit</a>
                <a href="hapus_kue.php?id=<?= $row['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Hapus kue?')">Delete</a>
            </div>
        </div>
    </div>
<?php endwhile; ?>
</div>

<a href="tambah_kue.php" class="btn btn-primary">Tambah Kue</a>

</body>
</html>
